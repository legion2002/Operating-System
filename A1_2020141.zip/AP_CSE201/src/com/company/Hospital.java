package com.company;

import java.util.ArrayList;

import java.util.Scanner;

public class Hospital {
    private int ID; //Leading zeroes
    private String name;
    private int pinCode; // Remember to check for leading zeroes while printing
    private static int IDgenerator = 0;
    private ArrayList<Slot> AvailableSlots;
    Scanner sc = new Scanner(System.in);

    public int getID() {
        return ID;
    }


    public int getPinCode() {
        return pinCode;
    }


    public ArrayList<Slot> getAvailableSlots() {
        return AvailableSlots;
    }




    Hospital(){
        IDgenerator++;
        System.out.println("\nHospital Name: ");
        this.name = sc.next();
        System.out.println("\nPinCode: ");
        this.pinCode = sc.nextInt(); //remember to check leading zeroes
        AssignID();
        AvailableSlots = new ArrayList<Slot>();

    }
    private void AssignID(){

        ID = IDgenerator + 100000;
    }
    public Slot createSlot(){
        Slot sl = new Slot(ID);
        AvailableSlots.add(sl);
        sl.print();
        return sl;
    }
    public void print(){
        System.out.println("\nHospital Name: " + this.name +  ", PinCode: " + pinCode + ", Unique ID: " + this.ID);
    }
    public void ListAvailableSlots(){
        for(int i = 0; i < AvailableSlots.size(); i++){
            Slot s = AvailableSlots.get(i);
            System.out.println("\nDay: " + s.getDayNum() + " Vaccine: " + s.getVaccineName() + " Available Qty: " + s.getVaccinesLeft());
        }
    }
}
