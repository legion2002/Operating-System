package com.company;

import java.util.Scanner;

public class Citizen {
    private String name;







    public void setVaccination_Status(String vaccination_Status) {
        Vaccination_Status = vaccination_Status;
    }

    public void setVaccineName(String vaccineName) {
        VaccineName = vaccineName;
    }

    public void setDueDate(int dueDate) {
        DueDate = dueDate;
    }

    private int age;
    private boolean ageValid;
    private final long ID;

    public void setNumDoses(int numDoses) {
        NumDoses = numDoses;
    }

    private String Vaccination_Status;
    private String VaccineName;
    private int NumDoses;
    private int DueDate;
    Scanner sc = new Scanner(System.in);

    public String getName() {
        return name;
    }


    public boolean isAgeValid() {
        return ageValid;
    }

    public long getID() {
        return ID;
    }

    public String getVaccination_Status() {
        return Vaccination_Status;
    }

    public String getVaccineName() {
        return VaccineName;
    }

    public int getNumDoses() {
        return NumDoses;
    }

    public int getDueDate() {
        return DueDate;
    }

    Citizen(){
        this.Vaccination_Status = "REGISTERED";
        this.VaccineName = null;
        System.out.println("\nCitizen Name: ");
        this.name = sc.next();
        System.out.println("\nAge");
        this.age = sc.nextInt();
        if(this.age < 18){
            ageValid = false;
        }
        else{
            ageValid = true;
        }
        System.out.println("\nUnique ID: ");
        this.ID = sc.nextLong();
        this.DueDate = 0;

    }
    public void print(){



        System.out.print("\nCitizen Name: " + this.name + ", Age: " + this.age + ", Unique ID: ");
        long temp = ID;
        String ID_String = "";
        for(int i = 0; i < 12; i++){
            ID_String = Integer.toString((int)(temp%10)) + ID_String;
            temp = temp/10;
        }
        System.out.println(ID_String);

        if(!ageValid){
            System.out.println("Only above 18 are allowed");
        }
    }
}
