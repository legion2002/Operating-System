package com.company;




import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class Portal {
    final private HashMap<Integer, Hospital> Registered_Hospitals;
    final private HashMap<String, Vaccine> Registered_Vaccines;
    final private HashMap<Long, Citizen> Registered_Citizens;
    Scanner sc = new Scanner(System.in);

    Portal(){
        Registered_Hospitals = new HashMap<Integer, Hospital>();
        Registered_Vaccines = new HashMap<String, Vaccine>();
        Registered_Citizens = new HashMap<Long, Citizen>();

    }
    public void AddVaccine(){
        Vaccine v = new Vaccine();
        Registered_Vaccines.put(v.getName(), v);
        v.print();

    }
    public void RegisterHospital(){
        Hospital h = new Hospital();
        Registered_Hospitals.put(h.getID(), h);
        h.print();

    }
    public void RegisterCitizen(){
        Citizen c = new Citizen();
        if(c.isAgeValid()) {
            Registered_Citizens.put(c.getID(), c);
        }
        c.print();
    }

    public void CreateSlot(){
        int hospID;
        int numQueries;
        System.out.println("\nEnter Hospital ID: ");
        hospID = sc.nextInt();
        System.out.println("\nEnter number of Slots to be added: ");
        numQueries = sc.nextInt();
        Hospital match = Registered_Hospitals.get(hospID);
        for(int i = 0; i < numQueries; i++){
            int count = 0;
            for(Map.Entry hospital : Registered_Vaccines.entrySet()){
                String name  =(String) hospital.getKey();
                System.out.println("\n" +  count + ". " + name);
                count++;
            }
            Slot newSlot= match.createSlot();
            //check if it is already present or not
            Registered_Vaccines.get(newSlot.getVaccineName()).getAvailableHospitals().add(match);
        }

    }
    public void BookSlot(){
        long patientID;
        System.out.println("\nEnter Patient Unique ID: ");
        patientID = sc.nextLong();
        Citizen currCitizen = Registered_Citizens.get(patientID);
        if(currCitizen.getVaccination_Status().equals("FULLY VACCINATED")){
            System.out.println("\n" + currCitizen.getName() + " is already fully vaccinated");
            return;
        }
        System.out.println("""

                1. Search by area
                2. Search by vaccine
                3. Exit"""
        );
        int option;
        System.out.println("\nEnter option: ");
        option = sc.nextInt();
        if(option == 3){
            return;
        }
        else if (option == 2){
            System.out.println("\nEnter Vaccine Name: ");
            String vaccine = sc.next(); //check for lower case and upper case here
            //Registered vaccines has been changed, change this
            Registered_Vaccines.get(vaccine).printHospitals();
//            for(int i = 0; i < Registered_Vaccines.size(); i++){
//                if(Registered_Vaccines.get(i).getName().equalsIgnoreCase(vaccine)){
//                    Registered_Vaccines.get(i).printHospitals();
//                    break;
//                }
//            }
        }
        else if(option == 1){
            System.out.println("\nEnter PinCode: ");
            int pincode = sc.nextInt();
            for(Map.Entry hospital : Registered_Hospitals.entrySet()){
                int key  =(int) hospital.getKey();
                if(Registered_Hospitals.get(key).getPinCode() == pincode){
                    Registered_Hospitals.get(key).print();
                }
            }
        }
        System.out.println("Enter Hospital ID: ");
        int SlotHospital = sc.nextInt();
        int SlotFlag = 0;
        if(Registered_Hospitals.get(SlotHospital).getAvailableSlots() == null){
            System.out.println("No slots available");
            return;
        }
        for(int i = 0; i < Registered_Hospitals.get(SlotHospital).getAvailableSlots().size(); i++ ) {
            Slot check  = Registered_Hospitals.get(SlotHospital).getAvailableSlots().get(i);
            //check here if you have to display slots that are not available for the citizen
            if(check.getVaccinesLeft() > 0 && check.getDayNum() >= currCitizen.getDueDate()){
                if(currCitizen.getVaccination_Status().equals("REGISTERED")) {
                    //Check if they have searched by vaccine, if we have to print only those vaccines
                    System.out.println("\n" + i + "->" + check.getHospital_ID() + " Day: " + check.getDayNum() + " , Available Quantity: " + check.getVaccinesLeft() + " of " + check.getVaccineName());
                    SlotFlag = 1;
                }
                else if(check.getVaccineName().equalsIgnoreCase(currCitizen.getVaccineName())){
                    System.out.println("\n" + i + "->" + check.getHospital_ID() + " Day: " + check.getDayNum() + " , Available Quantity: " + check.getVaccinesLeft() + " of " + check.getVaccineName());
                    SlotFlag = 1;
                }
            }


        }
        if(SlotFlag == 0){
            System.out.println("No slots available");
            return;
        }
        System.out.println("\nChoose Slot: (-1 to exit) ");
        int SlotChoice = sc.nextInt();
        if(SlotChoice == -1){
            return;
        }
        else{
            System.out.println("\n" + currCitizen.getName() + " Vaccinated with " + Registered_Hospitals.get(SlotHospital).getAvailableSlots().get(SlotChoice).getVaccineName());
        }
        //Check if slot choice is valid or not
        Registered_Hospitals.get(SlotHospital).getAvailableSlots().get(SlotChoice).setVaccinesLeft(Registered_Hospitals.get(SlotHospital).getAvailableSlots().get(SlotChoice).getVaccinesLeft() - 1);

        currCitizen.setNumDoses(currCitizen.getNumDoses() + 1);
        currCitizen.setVaccineName( Registered_Hospitals.get(SlotHospital).getAvailableSlots().get(SlotChoice).getVaccineName());

        if(currCitizen.getNumDoses() < Registered_Vaccines.get(currCitizen.getVaccineName()).getNumDoses()){
            currCitizen.setVaccination_Status( "PARTIALLY VACCINATED");
            currCitizen.setDueDate(Registered_Hospitals.get(SlotHospital).getAvailableSlots().get(SlotChoice).getDayNum() + Registered_Vaccines.get(currCitizen.getVaccineName()).getGap());



        }
        else{
            currCitizen.setVaccination_Status("FULLY VACCINATED");
        }


    }
    public void CheckHospitalSlots(){
        System.out.println("\nEnter Hospital ID: ");
        int hospID = sc.nextInt();
        Hospital match =  Registered_Hospitals.get(hospID);
        match.ListAvailableSlots();
    }
    public void CheckVaccinationStatus(){
        System.out.println("\nEnter Patient ID: ");
        long queryID = sc.nextLong();
        Citizen match = Registered_Citizens.get(queryID);
        if(match.getVaccination_Status().equals("REGISTERED")){
            System.out.println("\nCitizen REGISTERED");
        }
        else if(match.getVaccination_Status().equals("PARTIALLY VACCINATED")){
            System.out.println("\nPARTIALLY VACCINATED");
            System.out.println("\nVaccine Given: " + match.getVaccineName());
            System.out.println("\nNumber of Doses Given: " + match.getNumDoses());
            System.out.println("\nNext Dose due date: " + match.getDueDate());
        }
        else{
            System.out.println("\nFULLY VACCINATED");
            System.out.println("\nVaccine Given: " + match.getVaccineName());
            System.out.println("\nNumber of Doses Given: " + match.getNumDoses());
        }


    }
//    public static void PrintVaccineList(){
//        int count = 0;
//        for(Map.Entry hospital : Registered_Vaccines.entrySet()){
//            String name  =(String) hospital.getKey();
//            System.out.println("\n" +  count + ". " + name);
//            count++;
//        }
//    }

}
