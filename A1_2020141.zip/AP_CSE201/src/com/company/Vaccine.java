package com.company;

import java.util.ArrayList;
import java.util.Scanner;

public class Vaccine {
    private String name;
    private int NumDoses;
    private int gap;

    public String getName() {
        return name;
    }

    public int getNumDoses() {
        return NumDoses;
    }


    public int getGap() {
        return gap;
    }

    public void setGap(int gap) {
        this.gap = gap;
    }

    public ArrayList<Hospital> getAvailableHospitals() {
        return AvailableHospitals;
    }

    public void setAvailableHospitals(ArrayList<Hospital> availableHospitals) {
        AvailableHospitals = availableHospitals;
    }

    private ArrayList<Hospital> AvailableHospitals = new ArrayList<Hospital>();
    Scanner sc = new Scanner(System.in);
    Vaccine(){
        System.out.println("\nVaccine Name: ");
        name = sc.next();
        System.out.println("\nNumber of Doses: ");
        NumDoses = sc.nextInt();
        if(NumDoses != 1) {
            System.out.println("\nGap between Doses: ");
            gap = sc.nextInt();
        }
        else{
            gap = 0;
        }
    }
    public void print(){
        System.out.println("Vaccine Name: "+name+", Number of Doses: "+ NumDoses+ ", Gap between Doses: " + gap);
    }
    public void printHospitals(){
        for(int i = 0; i < AvailableHospitals.size(); i++){
            AvailableHospitals.get(i).print();
        }
    }
}