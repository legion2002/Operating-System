package com.company;
import java.util.*;
import java.lang.*;

public class Main {
    private static Portal portal;
    final private static String menuTemplate = """
            ------------------------------------
            1. Add Vaccine
            2. Register Hospital
            3. Register Citizen
            4. Add Slot for Vaccination
            5. Book Slot for Vaccination
            6. List all slots for a hospital
            7. Check Vaccination Status
            8. Exit
            ------------------------------------
            """;
    private static int query = 0;


    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        portal = new Portal();
        if(portal != null){
            System.out.println("Cowin Portal Initialized...");
        }

        while(true){

            System.out.println(menuTemplate);
            query = sc.nextInt();
            if(query == 8){
                System.out.println("Thank you, Made by - Tanishk Goyal (2020141) ");
                return;
            }
            else if(query == 7){
                portal.CheckVaccinationStatus();
            }
            else if(query == 6){
                portal.CheckHospitalSlots();
            }
            else if(query == 5){
                portal.BookSlot();
            }
            else if(query == 4){
                portal.CreateSlot();
            }
            else if(query == 3){
                portal.RegisterCitizen();
            }
            else if(query == 2){
                portal.RegisterHospital();
            }
            else if(query == 1){
                portal.AddVaccine();
            }
        }
    }
}
