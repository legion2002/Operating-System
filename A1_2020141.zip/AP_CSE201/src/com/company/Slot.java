package com.company;


import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class Slot {
    private int DayNum;
    private int VaccinesLeft;
    private String VaccineName;
    private final int Hospital_ID;
    Scanner sc = new Scanner(System.in);

    public int getDayNum() {
        return DayNum;
    }

    public void setDayNum(int dayNum) {
        DayNum = dayNum;
    }

    public int getVaccinesLeft() {
        return VaccinesLeft;
    }

    public void setVaccinesLeft(int vaccinesLeft) {
        VaccinesLeft = vaccinesLeft;
    }

    public String getVaccineName() {
        return VaccineName;
    }


    public int getHospital_ID() {
        return Hospital_ID;
    }


    //Should not be accessing vaccines directly
    Slot(int hospID){
        System.out.println("\nEnter Day Number: ");
        this.DayNum = sc.nextInt();
        System.out.println("\nEnter Quantity: ");
        this.VaccinesLeft = sc.nextInt();
        //Might Have to change this


        System.out.println("Choose Vaccine (by name)");
        this.VaccineName = sc.next();
        this.Hospital_ID = hospID;


    }
    public void print(){
        System.out.println("\nSlot added by Hospital " + Hospital_ID + " for Day: " + DayNum + " , Available Quantity: " + VaccinesLeft + " of " + VaccineName);
    }
}
