#include<stdio.h>
#include<stdlib.h>

void C(){
    printf("\nYou are now in C function\n");
    exit(0);
}